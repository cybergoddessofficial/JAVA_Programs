package array_programs;

public class ArrayEx3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
//		Object a[]=new Object[5];
		Object a[]= {10,"hiii",'h',10.5,true,20000};
		a[0]=10;
		a[1]="hi";
		a[2]='h';
		a[3]=10.5;
		a[4]=true;
		for(Object i:a)
		{
			System.out.println(i);
		}
	}

}
