package basics;

public class Operators {

	public static void main(String[] args) {
		int a=10;
		int b=20;
		int c=a+b; //30
		//Arithmetic Operator 
		System.out.println("Sum:"+c);
		System.out.println("sub:"+(a-b));
		System.out.println(a*b);
		System.out.println(a/b);
		System.out.println(a%b);
//		Logical Operator
		boolean x=true;
		boolean y=false;
		System.out.println(x && y);
		System.out.println(x || y);
		System.out.println(!x);
		System.out.println(!y);
		
		System.out.println("----------------------------");
//		Relational Operators: a:10 b:20
		System.out.println(a>b); //false
		System.out.println(a<b); //true
		System.out.println(a<=b); //true
		System.out.println(a>=b); //false
		System.out.println(a==b); //false
		System.out.println(a!=b); //true
		System.out.println("----------------------------");
		System.out.println("Assignment Operators");
		System.out.println("----------------------------");
		int n=c;
		System.out.println(n); //30
		n=a;
		System.out.println(n); //10
		n+=a;	//n=10 n+=a n=n+a n=10+10=20
		System.out.println(n);
		n-=a;
		System.out.println(n); // n-=a  n=20 n=n-a n=20-10=10
		//n*=a  n/=a
		
		System.out.println("----------------------------");
		
		//increment
		int l=20;
		System.out.println(l);
		l++;
		System.out.println(l);
		
		//decrement
		l--;
		System.out.println(l);
		
		
		
		
		
		
		
		
		

	}

}
