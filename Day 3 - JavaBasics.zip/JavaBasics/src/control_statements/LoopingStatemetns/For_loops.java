package control_statements.LoopingStatemetns;

public class For_loops {
	public static void main(String[] args)
	{
//		for(int i=1;i<=10;i++)
//		{
//			System.out.println(i);
//		}
		for(int i=10;i>=1;i--)
		{
			if(i==5)
			{
//				break;
				continue;
			}
			else
			{
				System.out.println(i);
			}
			
		}
	}

}
