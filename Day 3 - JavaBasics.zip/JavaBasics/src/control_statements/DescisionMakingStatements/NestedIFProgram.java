package control_statements.DescisionMakingStatements;

public class NestedIFProgram {

	public static void main(String[] args) {
		int age=363;
		if(age<18)
		{
			System.out.println("You're minor");
		}
		else if(age>=18 && age<60)//63>=18
		{
			System.out.println("You're major");
		}
		else if(age>=60 && age<100)
		{
			System.out.println("you're retired");
		}
		else {
			System.out.println("Program exited...error");
		}

	}

}
