package control_statements.DescisionMakingStatements;

public class Ifconditions {

	public static void main(String[] args) {
		int age=5;
		if(age>=18)//25>=18 true
		{	
			//body of if
			System.out.println("You're eligible to vote");
		}
		else
		{
			//body of else
			System.out.println("You're not eligible");
		}
		//System.out.println("Program exited....");

	}

}
