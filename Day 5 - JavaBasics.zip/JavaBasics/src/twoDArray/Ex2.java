package twoDArray;

public class Ex2 {

	public static void main(String[] args) {
		int a[][]={{10,20},{30,40},{60,50}};
		
		for(int i[]:a)
		{
			for(int j:i)
			{
				System.out.print(j+" ");
			}
			System.out.println();
		}

	}

}
