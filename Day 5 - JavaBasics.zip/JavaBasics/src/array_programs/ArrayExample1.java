package array_programs;

public class ArrayExample1 {

	public static void main(String[] args) {
		//declaration of array with 5 elements
		//index : 0-4
//		int a[]=new int[5];
//		//initialize 
//		a[0]=10;
//		a[1]=20;
//		a[2]=30;
//		a[3]=40;
//		a[4]=50;
		
//		
//		System.out.println(a[0]);
//		System.out.println(a[2]);
		
//		for(int i=0;i<=4;i++)//0 1
//		{
//			System.out.println(a[i]);//a[0] //a[1]
//		}
		int a[]={1,2,3,5,6};
		
		for(int i:a)//10 20 30 40 50
		{
			System.out.println(i);//10 20
		}

	}

}
