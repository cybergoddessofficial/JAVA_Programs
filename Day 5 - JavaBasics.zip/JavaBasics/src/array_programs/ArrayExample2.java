package array_programs;

public class ArrayExample2 {

	public static void main(String[] args) {
//		int a[]=new int[5];
//		String s[]=new String[100];
//		
//		s[0]="hELLO";
//		s[1]="world";
////		s[2]="hai";
//		
//		System.out.println(s[0]);
//		
//		for(String i:s)
//		{
//			System.out.println(i);
//		}
//		
//		System.out.println(s.length);
//				
	}

}
