//return values
package oopsConcept;

public class Method3 {

	int a;
	int b;
	
	int sum()
	{
		return a+b;
	}
	public static void main(String[] args) {
		Method3 m3=new Method3();
		m3.a=1;
		m3.b=5;
		int result=m3.sum();
		System.out.println(result);

	}

}
