package oopsConcept;

public class Employee1 {
	
	
	int empid;
	String empname;
	int salary;
	int deptno;
	
	void setData(int id,String ename,int sal,int dpt)
	{
		empid=id;
		empname=ename;
		salary=sal;
		deptno=dpt;
	}
	void display()
	{
		System.out.println(empid);
		System.out.println(empname);
		System.out.println(salary);
		System.out.println(deptno);
	}
	
	public static void main(String[] args) {
		Employee1 emp=new Employee1();
		emp.setData(1,"nimisha",2,3);
		emp.display();

	}

}
