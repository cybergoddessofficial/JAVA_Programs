package oopsConcept;

public class Employee {
	int empid;
	String empname;
	int salary;
	int deptno;
	
	Employee(int empid,String ename,int sal,int dpt)
	{
		empid=empid;
		empname=ename;
		salary=sal;
		deptno=dpt;
	}
	void display()
	{
		System.out.println(empid);
		System.out.println(empname);
		System.out.println(salary);
		System.out.println(deptno);
	}
	
	public static void main(String[] args)
	{
		Employee emp=new Employee(1,"nimisha",2,3);
//		emp.empid=100;
//		emp.empname="Demo";
//		emp.salary=25000;
//		emp.deptno=2;
		emp.display();
		
		
		
//		Employee emp1=new Employee();
//		emp.empid=101;
//		emp.empname="Demo1";
//		emp.salary=250002;
//		emp.deptno=22;
//		emp.display();
		
		
	}

}



