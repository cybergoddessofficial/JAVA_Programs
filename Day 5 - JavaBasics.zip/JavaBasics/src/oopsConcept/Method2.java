//with para
package oopsConcept;

public class Method2 {

	int a;
	int b;
	
	void sum(int x,int y)
	{	
		a=x;
		b=y;
		System.out.println(a+b);
	}
	public static void main(String[] args) {
		Method2 m2=new Method2();
		m2.sum(100,200);

	}

}
