//method not takes para(empty parameters)
package oopsConcept;

public class Method1 {
	int a;
	int b;
	void sum()
	{
		System.out.println(a+b);
	}

	public static void main(String[] args) {
		
		Method1 m=new Method1();
		m.a=10;
		m.b=20;
		m.sum();
		

	}

}
