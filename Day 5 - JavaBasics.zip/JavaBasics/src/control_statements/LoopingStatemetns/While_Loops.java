package control_statements.LoopingStatemetns;

public class While_Loops {

	public static void main(String[] args) {
		//print 1-10 number
//		int i=1;
//		while(i<=10)//1<=10	2<=10	......10<=10	11<=10
//		{
//			System.out.println(i);//1	2....10
//			i++;//2	3......10	11
//		}
		
		int i=0;//intiliazatin
		while(i>=1)//10>=1	9>=1	0>=1 //conditon
		{
			System.out.println(i);//10	9...1
			i--;//9	8........0//incre/decre
		}
		System.out.println("error");
		
		

	}

}
