package control_statements.DescisionMakingStatements;

public class Switch_char {

	public static void main(String[] args) {
		char option='d';
		switch(option)
		{
		case 'a':
			System.out.println("this is case a");
			break;
		case 'b':
			System.out.println("this is case b");
			break;
		case 'd':
			System.out.println("this is case d");
			break;
		default:
			System.out.println("invalid case");
		}

	}

}
