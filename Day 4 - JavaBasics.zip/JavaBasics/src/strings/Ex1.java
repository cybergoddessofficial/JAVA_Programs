package strings;

public class Ex1 {

	public static void main(String[] args) {
		String s="Welcome";
		System.out.println(s.length());
		int j=s.length();
		System.out.println(j);
		
		String s1="hello";
		String s2="Welcome";
		System.out.println(s1+s2);
		System.out.println(1+2);
		System.out.println(s1.concat(s2));
		System.out.println("Welcome"+" "+"All");
		System.out.println("Welcome".concat("Demo"));
		String s3="HELLO";
		String s4="HELLO";
		System.out.println(s1.equals(s3));
		System.out.println(s1.equalsIgnoreCase(s3));
		
		System.out.println(s4.contains("el"));
		String s5="World!!!";
		System.out.println(s5.substring(2));
		String s6="WELCOME";
		System.out.println(s6.substring(0,4));
		
		System.out.println(s6.replace('E','a'));
		System.out.println(s6.replace("LC", "AC"));
		System.out.println(s6.replace("W", "M"));

	}

}
