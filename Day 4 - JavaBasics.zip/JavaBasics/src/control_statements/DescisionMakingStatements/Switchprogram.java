package control_statements.DescisionMakingStatements;

public class Switchprogram {

	public static void main(String[] args) {
		int a=3;
		switch(a)//3
		{	
		case 1:
			System.out.println("Monday");
			break;
		case 2:
			System.out.println("Tuesday");
			break;
		case 3:
			System.out.println("Wednesday");
			break;
		case 4:
			System.out.println("Thursday");
			break;
		default:
			System.out.println("invalid number");
		}

	}

}
