package twoDArray;

public class Example1 {

	public static void main(String[] args) {
		// declartion
		int a[][]=new int[3][2];
		//a[r][c]
		a[0][0]=10;
		a[0][1]=20;
		a[1][0]=30;
		a[1][1]=40;
		a[2][0]=50;
		a[2][1]=60;
		
//		System.out.println(a[0][0]);
		//method 1- classic for loop
//		for(int i=0;i<=2;i++)//(row 0-2)
//		{
//			for(int j=0;j<=1;j++)//(col 0-1)2
//			{
////				System.out.println(a[i][j]);//a[r][c]
//				System.out.print(a[i][j]+" ");//10  20
//			}
//			System.out.println();//new line
//		}
		
		
		//method 2 : for each loop
		for(int i[]:a)
		{
			for(int j:i)
			{
				System.out.print(j+" ");
			}
			System.out.println();
		}
		
		
		
		

	}

}
