package basics;

public class HelloWorld {

	public static void main(String[] args) {
		System.out.println("Hello World");
		System.out.println(2.3);
		int a;
		a=10;
		double b=2.3;
		char c='A';
		String name="NIMISHA nim";
		boolean d=true;
		String z="true";
		System.out.println(d);
		System.out.println(a);
		System.out.println(b);
		System.out.println(c);
		System.out.println(name);
		

	}

}
