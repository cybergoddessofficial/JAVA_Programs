package control_statements.LoopingStatemetns;

public class Do_While {

	public static void main(String[] args) {
//		do{
//
//			//statements body of do
//			//incre decre
//		}while(<condition>
		
//		int i=100; //intiliati
//		do {
//			System.out.println(i);
//			i++;//increment i=i+1 i+=1
//		}while(i<=10);//condition
//
		int i=2;
		do {
			System.out.println(i);//1 3
//			i=i+1;//3
//			i++;
//			
			i+=1;
		}while(i<=10);//3<=10
		
		
		
	}

}
