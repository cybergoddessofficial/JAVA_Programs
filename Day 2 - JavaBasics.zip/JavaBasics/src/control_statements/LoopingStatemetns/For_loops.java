package control_statements.LoopingStatemetns;

public class For_loops {
	public static void main(String[] args)
	{
		
	}

}
